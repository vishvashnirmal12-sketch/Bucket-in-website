LAUNDRY BUCKET IN WEBSITE
Open index.html in a browser to preview.
The site is responsive for mobile and desktop.
WhatsApp and phone buttons are connected to 7800400499.
Address: Dhanukar Waadi, Datt Mandir, Kandivali (W), Mumbai - 400067.
Owner: Umashankar jagelaal nirmal.
